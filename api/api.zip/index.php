<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require 'db.php';

$request_uri = $_SERVER['REQUEST_URI'];
$path = parse_url($request_uri, PHP_URL_PATH);

// Sadece /api/... formatındaki isteklere izin ver (direkt /home vb. engellendi)
if (strpos($path, '/api') === false) {
    http_response_code(404);
    echo json_encode([
        'success' => false,
        'message' => 'Gecersiz endpoint formati. Lutfen istekleri /api/[rota] formatinda yapin.'
    ]);
    exit;
}

if (isset($_GET['route'])) {
    $routeParts = explode('/', trim($_GET['route'], '/'));
} else {
    $routeParts = explode('/', trim($path, '/'));
}
$route = end($routeParts);

$response = [
    'success' => true,
    'data' => null
];

try {
    require_once 'controllers/PageController.php';
    
    switch ($route) {
        case 'home':
            $response['data'] = getHomeData($pdo);
            break;

        case 'contact':
            $response['data'] = getContactData($pdo);
            break;

        case 'rooms':
            $response['data'] = getRoomsData($pdo);
            break;

        case 'restaurant':
            $response['data'] = getRestaurantData($pdo);
            break;
            
        case 'event':
            $response['data'] = getEventData($pdo);
            break;

        default:
            http_response_code(404);
            $response = [
                'success' => false,
                'message' => 'Gecersiz veya bulunamayan rota.'
            ];
            break;
    }
} catch (PDOException $e) {
    http_response_code(500);
    $response = [
        'success' => false,
        'message' => 'Veritabani hatasi.',
        'error_details' => $e->getMessage()
    ];
}

echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
